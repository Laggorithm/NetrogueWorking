﻿using System;
using System.Collections.Generic;
using System.Windows;
using System.Numerics; // Needed for Vector2
using ZeroElectric.Vinculum;
using Netrogue;
using System.Diagnostics;
using System.IO;

namespace EnemyEditor
{
    public partial class MainWindow : Window
    {
        private string FilePath { get; set; } = Path.Combine(Directory.GetCurrentDirectory(), "enemies.json");

        private List<Enemy> enemies;
        private EnemyDataManager enemyDataManager;

        public MainWindow()
        {
            InitializeComponent();
            enemyDataManager = new EnemyDataManager(FilePath);
            LoadEnemies();
        }

        private void LoadEnemies()
        {
            enemies = enemyDataManager.LoadEnemies();
            EnemyListBox.ItemsSource = enemies;
        }

        private void CreateJsonFileButton_Click(object sender, RoutedEventArgs e)
        {
            string directoryPath = Path.GetDirectoryName(FilePath);
            if (!Directory.Exists(directoryPath))
            {
                Directory.CreateDirectory(directoryPath);
            }

            if (!File.Exists(FilePath))
            {
                File.WriteAllText(FilePath, "[]");
                NotificationTextBlock.Text = "JSON file created successfully.";
            }
            else
            {
                NotificationTextBlock.Text = "JSON file already exists.";
            }
        }

        private void CreateNewMobButton_Click(object sender, RoutedEventArgs e)
        {
            Enemy newEnemy = new Enemy
            {
                MobName = "New Mob",
                SpriteIndex = 0,
                 
                Position = new Position(0, 0) // Initialize Position
            };

            enemies.Add(newEnemy);
            EnemyListBox.ItemsSource = null;
            EnemyListBox.ItemsSource = enemies;

            EnemyListBox.SelectedItem = newEnemy;
        }

        private void EnemyListBox_SelectionChanged(object sender, System.Windows.Controls.SelectionChangedEventArgs e)
        {
            if (EnemyListBox.SelectedItem is Enemy selectedEnemy)
            {
                NameTextBox.Text = selectedEnemy.MobName;
                SpriteIdTextBox.Text = selectedEnemy.SpriteIndex.ToString();
                 
                PositionXTextBox.Text = selectedEnemy.Position.X.ToString();
                PositionYTextBox.Text = selectedEnemy.Position.Y.ToString();
            }
        }

        private void SaveButton_Click(object sender, RoutedEventArgs e)
        {
            if (EnemyListBox.SelectedItem is Enemy selectedEnemy)
            {
                selectedEnemy.MobName = NameTextBox.Text;
                selectedEnemy.SpriteIndex = int.Parse(SpriteIdTextBox.Text);
               

                float posX = float.TryParse(PositionXTextBox.Text, out float x) ? x : 0;
                float posY = float.TryParse(PositionYTextBox.Text, out float y) ? y : 0;
                selectedEnemy.Position = new Position(posX, posY); // Update to use Position class

                enemyDataManager.SaveEnemies(enemies);
                NotificationTextBlock.Text = "Enemy saved successfully.";
            }
            else
            {
                NotificationTextBlock.Text = "Select an enemy to save.";
            }
        }

        private void OpenDirectoryButton_Click(object sender, RoutedEventArgs e)
        {
            string directoryPath = Path.GetDirectoryName(FilePath);

            if (Directory.Exists(directoryPath))
            {
                Process.Start(new ProcessStartInfo
                {
                    FileName = directoryPath,
                    UseShellExecute = true,
                    Verb = "open"
                });
            }
            else
            {
                NotificationTextBlock.Text = "Directory does not exist.";
            }
        }

        private void NameTextBox_TextChanged(object sender, System.Windows.Controls.TextChangedEventArgs e) { /* Update logic here */ }
        private void SpriteIdTextBox_TextChanged(object sender, System.Windows.Controls.TextChangedEventArgs e) { /* Update logic here */ }
        private void HitPointsTextBox_TextChanged(object sender, System.Windows.Controls.TextChangedEventArgs e) { /* Update logic here */ }

        private void PositionXTextBox_TextChanged(object sender, System.Windows.Controls.TextChangedEventArgs e) { /* Update logic here */ }
        private void PositionYTextBox_TextChanged(object sender, System.Windows.Controls.TextChangedEventArgs e) { /* Update logic here */ }
    }
}
