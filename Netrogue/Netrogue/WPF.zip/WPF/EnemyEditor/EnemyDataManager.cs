﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text.Json;

namespace Netrogue
{
    public class EnemyDataManager
    {
        public string FilePath { get; set; }

        public EnemyDataManager(string filePath)
        {
            FilePath = filePath;
        }

        public void SaveEnemies(List<Enemy> enemies)
        {
            var options = new JsonSerializerOptions { WriteIndented = true };
            string json = JsonSerializer.Serialize(enemies, options);
            File.WriteAllText(FilePath, json);
        }

        public List<Enemy> LoadEnemies()
        {
            if (!File.Exists(FilePath))
                return new List<Enemy>();

            string json = File.ReadAllText(FilePath);
            return JsonSerializer.Deserialize<List<Enemy>>(json);
        }
    }
}
